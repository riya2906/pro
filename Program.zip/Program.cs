﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
       /*(question 1) static void Main(string[] args)
             {
            double x, y;

            Console.WriteLine("Student's age");
            String num = Console.ReadLine();
            double age = double.Parse(num);
            Console.WriteLine("International Student");
            string a = Console.ReadLine();
            Console.WriteLine("Registration Semester");
            string b = Console.ReadLine();
            if (a == "no")
            {
                if (age <= 18)
                { 
                x=300+(13/100*300);
                Console.WriteLine("Base Tuition" +x);
                }
                else if (age <= 49)
                {
                    x = 500 + (13 / 100 * 300);
                    Console.WriteLine("Base Tuition" + x);
                }
                else { 
                x=400+(13/100*400);
                Console.WriteLine("Base Tuition" +x);
                }
            }
                else if (a=="yes")
                {
                if(age<=18)
                {
                x=400+(13/100*400);
                    Console.WriteLine("Internation Student fee" +x);
                }
                else if(age<=49)
                {
                x=600+(13/100*600);
                    Console.WriteLine("International Student fee" +x);
                }
                else{
                x=500+(13/100*500);
                    Console.WriteLine("International Student fee" +x);
                }
                
            switch(b)
            {
                case "fall":
                    {
                    y=250+(13/100*250);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                case  "winter":
                    {
                    y=250+(13/300*220);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                case "summer":
                    {
                    y=150+(13/300*150);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                default:
                    {
                    Console.WriteLine("Enter valid month");
                        break;
                    } (end of question 1)*/




       /*(question 2) static double volume(double radius)
        {
            double volofsphere, pi;
            pi = 3.14;
            volofsphere = 4 / 3 * pi * radius * radius * radius * radius;
            Console.WriteLine("volume of sphere is" + volofsphere);
            return volofsphere;
        }
        static double volume(double r, double height)
        {
            double vol, pi;
            pi = 3.14;
            vol = pi * r * r * height;
            Console.WriteLine("volume of cylinder is" + vol);
            return vol;
        }
        static double volume(double length, double width, double h)
        {
            double volrectangularprism;
            volrectangularprism = length * width * h;
            Console.WriteLine("Volume of rectangular prism is" + volrectangularprism);
            return volrectangularprism;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("select");
            Console.WriteLine("1 for volume of sphere");
            Console.WriteLine("2 for volume of cylinder");
            Console.WriteLine("3 for volume of rectangular prism");
            string x = Console.ReadLine();
            int value = int.Parse(x);
            if (value == 1)
            {
                Console.WriteLine("Enter radius of sphere");
                string y = Console.ReadLine();
                double rad = double.Parse(y);
                volume(rad);
            }
            else if (value == 2)
            {
                Console.WriteLine("Enter radius and height of cylinder");
                String a = Console.ReadLine();
                double r = double.Parse(a);
                String b = Console.ReadLine();
                double h = double.Parse(b);
                volume(r, h);
            }
            else if (value == 3)
            {
                Console.WriteLine("Enter length,width and height of rectangular sphere");
                string c = Console.ReadLine();
                double l = double.Parse(c);
                string d = Console.ReadLine();
                double w = double.Parse(d);
                string e = Console.ReadLine();
                double f = double.Parse(e);
                volume(l, w, f);
            } (end of question 2)*/
            }
        }
    }

